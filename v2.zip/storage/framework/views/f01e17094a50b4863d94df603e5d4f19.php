<!-- Start Soul Working Process 
====================================================-->
<section class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="title mb-30 w-50 lg-w-80 text-center mx-auto">
                    <span class="color-primary">How We Innovate</span>
                    <h2 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">Our Working Process</h2>
                    <p>
                        At Soul, we follow a clear, human-centered process that ensures innovation, quality, and impact. From idea to deployment, every step is focused on creating meaningful solutions for industries and healthcare.
                    </p>
                </div>
            </div>

            <!-- Step 1 -->
            <div class="col-xl-3 col-lg-6 col-md-6">
                <span class="number-border mx-auto color-primary mt-30">1</span>
                <div class="box-style-1 text-center px-30 py-40 box-shadow bg-white mt-30 shadow-thik-black-01-hov transition-5 hov-trans-b-t-5 shadow-smooth-black-01">
                    <div class="position-relative">
                        <h4 class="box-title color-secondery mb-20">Concept & Ideation</h4>
                        <p class="mb-0">
                            We start with brainstorming and defining innovative ideas, focused on solving real-world challenges and improving lives.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="col-xl-3 col-lg-6 col-md-6">
                <span class="number-border mx-auto color-primary mt-30">2</span>
                <div class="box-style-1 text-center px-30 py-40 box-shadow bg-white mt-30 shadow-thik-black-01-hov transition-5 hov-trans-b-t-5 shadow-smooth-black-01">
                    <div class="position-relative">
                        <h4 class="box-title color-secondery mb-20">Research & Analysis</h4>
                        <p class="mb-0">
                            Our team analyzes markets, technology trends, and user needs to ensure our solutions are effective, efficient, and impactful.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="col-xl-3 col-lg-6 col-md-6">
                <span class="number-border mx-auto color-primary mt-30">3</span>
                <div class="box-style-1 text-center px-30 py-40 box-shadow bg-white mt-30 shadow-thik-black-01-hov transition-5 hov-trans-b-t-5 shadow-smooth-black-01">
                    <div class="position-relative">
                        <h4 class="box-title color-secondery mb-20">Development & Innovation</h4>
                        <p class="mb-0">
                            We develop smart, AI-driven, and wearable solutions that transform communication, productivity, and healthcare efficiency.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Step 4 -->
            <div class="col-xl-3 col-lg-6 col-md-6">
                <span class="number-border mx-auto color-primary no-border mt-30">4</span>
                <div class="box-style-1 text-center px-30 py-40 box-shadow bg-white mt-30 shadow-thik-black-01-hov transition-5 hov-trans-b-t-5 shadow-smooth-black-01">
                    <div class="position-relative">
                        <h4 class="box-title color-secondery mb-20">Launch & Support</h4>
                        <p class="mb-0">
                            After deployment, we provide continuous support and updates, ensuring our solutions evolve with user needs and industry changes.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- End Soul Working Process 
====================================================-->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/Process.blade.php ENDPATH**/ ?>
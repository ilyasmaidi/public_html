<!-- ================== آراء العملاء ================== -->
<div class="testimonial-area style-three bg_primary position-relative z-1 pt-130 pb-100">
    <img src="<?php echo e(asset('assets/img/box-shape-4.png')); ?>" alt="شكل" class="section-shape position-absolute top-0 end-0 z-n1">
    <img src="<?php echo e(asset('assets/img/box-shape-5.png')); ?>" alt="شكل" class="section-shape position-absolute bottom-0 start-0 z-n1">

    <div class="circle-text-wrapper position-relative">
        <div class="move-text-wrapper">
            <div class="move-text style-one overflow-hidden z-1">
                <ul class="list-unstyled mb-0">
                    <li class="position-relative font-secondary">اكتشف الآن ماذا يقول عملاؤنا عنا</li>
                    <li class="position-relative font-secondary">موثوق بنا من قبل الشركات حول العالم</li>
                    <li class="position-relative font-secondary">اكتشف الآن ماذا يقول عملاؤنا عنا</li>
                    <li class="position-relative font-secondary">موثوق بنا من قبل الشركات حول العالم</li>
                </ul>
            </div>
        </div>

        <div class="container style-one">
            <div class="circle-text-wrap position-relative d-flex flex-column justify-content-center align-items-center rounded-circle">
                <img src="<?php echo e(asset('assets/img/trusted-clients.svg')); ?>" alt="صورة" class="circle-text d-lock mx-auto rotate">
                <img src="<?php echo e(asset('assets/img/icons/quote-2.svg')); ?>" alt="أيقونة" class="position-absolute">
            </div>
        </div>
    </div>

    <div class="container">
        <div class="testimonial-slider-three swiper">
            <div class="swiper-wrapper">

                <?php
                    $testimonials = [
                        [
                            'text' => 'من أفضل الشركات الناشئة الصاعدة كان لي شرف الاشراف عليهم و لقد قاموا بجهد يجب تثمينه فريق صاعد بقوة .',
                            'name' => 'حميدا فرحات',
                            'role' => 'مدير حاظنة أعمال',
                            'image' => 'assets/img/clients/client-1.jpg',
                        ],
                        [
                            'text' => 'مشروع طموح و فكرة ريادية إنسانية قل ما نلتقي بشباب يغيرون على بلده بهذا الطموح تمنياتي لكم بالنجاح , أنا مراقب على كثب لنشاطاتكم و إن شاء الله سوول إلى العالمية',
                            'name' => 'محمد دومير',
                            'role' => 'نجم العلوم 2013',
                            'image' => 'assets/img/clients/client-2.jpg',
                        ],
                        // يمكنك إضافة المزيد من العملاء هنا بسهولة
                    ];
                ?>

                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="testimonial-card style-three">
                            <div class="row">
                                <div class="col-xl-10 offset-xl-1 col-md-10 offset-md-1">
                                    <p class="font-secondary fw-medium text-white text-center">
                                        "<?php echo e($testimonial['text']); ?>"
                                    </p>
                                    <div class="client-info-wrap d-flex flex-wrap align-items-center justify-content-center">
                                        <div class="client-img rounded-circle">
                                            <img src="<?php echo e(asset($testimonial['image'])); ?>" alt="صورة" class="rounded-circle">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="fs-20 fw-medium text-white mb-0"><?php echo e($testimonial['name']); ?></h5>
                                            <span><?php echo e($testimonial['role']); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="slider-btn style-three">
                <button class="prev-btn testimonial-prev bg-transparent border-0 me-2 d-flex flex-column align-items-center justify-content-center rounded-circle">
                    <img src="<?php echo e(asset('assets/img/icons/left-arrow-secondary-large.svg')); ?>" alt="أيقونة">
                </button>
                <button class="next-btn testimonial-next bg-transparent border-0 ms-2 d-flex flex-column align-items-center justify-content-center rounded-circle">
                    <img src="<?php echo e(asset('assets/img/icons/right-arrow-secondary-large.svg')); ?>" alt="أيقونة">
                </button>
            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية آراء العملاء ================== -->
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/Testimonial.blade.php ENDPATH**/ ?>
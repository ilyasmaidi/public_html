<!-- Start Offer One -->
<div class="offer-banner-2 position-relative py-80">
    <div class="container">
        <div class="row">
            <!-- App Download Section -->
            <div class="col-lg-6 col-md-12">
                <div class="text-right download-app wow animated slideInLeft">
                    <div class="position-relative">
                        <h3 class="thumb-title color-white">
                            Download Soul Co Official Apps and Get Continuous Support for Autism Solutions!
                        </h3>
                        <div class="text-area color-white mt-15">
                            <p>
                                Access tools, insights, and real-time monitoring to help children on the spectrum. Stay connected, track progress, and enhance communication with ease.
                            </p>
                        </div>
                        <div class="btn-group mt-30">
                            <a class="btn btn-secondery mr-30 d-block md-mr-0" href="#">Google Play Store</a>
                            
                        </div>
                    </div>
                </div>
            </div>

            <!-- Consultation Form Section -->
            <div class="col-lg-6 col-md-12">
                <div class="get-help bg-dark p-40 lg-mt-30 wow animated slideInRight">
                    <h3 class="thumb-title color-white">Connect With Us for Consultation</h3>
                    <div class="text-area color-white mt-15">
                        <p>
                            Schedule a session with our specialists to get personalized guidance and support for autism care and technology solutions.
                        </p>
                    </div>
                    <form id="consultation-form" class="mt-15">
                        <div class="form-group">
                            <input class="form-control bg-gray" type="email" name="email" placeholder="Enter your email" required>
                        </div>
                        <div class="btn-group mt-10">
                            <button type="submit" class="btn btn-primary mr-30 d-block md-mr-0">Send</button>
                        </div>
                    </form>
                    <div id="success-message" class="mt-15 text-success" style="display:none;">
                        Your email has been saved successfully! 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Offer One -->

<!-- Add this script at the bottom of the Blade file -->
<script>
    const form = document.getElementById('consultation-form');
    const message = document.getElementById('success-message');

    form.addEventListener('submit', function(e) {
        e.preventDefault(); // منع إعادة تحميل الصفحة
        message.style.display = 'block'; // عرض الرسالة
        form.reset(); // إعادة تعيين الفورم
        setTimeout(() => {
            message.style.display = 'none'; // اختفاء الرسالة بعد 3 ثواني
        }, 3000);
    });
</script>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/offer.blade.php ENDPATH**/ ?>
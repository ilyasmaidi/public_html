<!-- ================== الفوتر ================== -->
<footer class="footer-area style-two position-relative z-1 pt-130">
    <div class="container style-one">
        <div class="row justify-content-center mb-40">
            <div class="col-lg-2 col-md-6" data-cue="slideInUp">
                <div class="footer-widget mb-30">
                    <a href="<?php echo e(url('/')); ?>" class="logo"><img src="<?php echo e(asset('assets/img/solo.png')); ?>" alt="شعار" class="logo-img"></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer-widget mb-30 ps-xxl-5 ms-xxl-1" data-cue="slideInUp">
                    <h3 class="footer-widget-title fs-18 fw-semibold">روابط سريعة</h3>
                    <ul class="footer-menu list-unstyled mb-0">
                        <li><a href="<?php echo e(url('about-us')); ?>">الميزات</a></li>
                        <li><a href="<?php echo e(url('about-us')); ?>">من نحن</a></li>
                        <li><a href="<?php echo e(url('testimonials')); ?>">آراء العملاء</a></li>
                        <li><a href="<?php echo e(url('pricing-plan')); ?>">الأسعار</a></li>
                        <li><a href="<?php echo e(url('blog-right-sidebar')); ?>">المدونة</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 ps-xxl-0 pe-xxl-5 pe-lg-4" data-cue="slideInUp">
                <div class="footer-widget mb-30">
                    <h3 class="footer-widget-title fs-18 fw-semibold">العنوان</h3>
                    <ul class="contact-info list-unstyled mb-0">
                        <li class="position-relative">
                            <img src="<?php echo e(asset('assets/img/icons/pin-small.svg')); ?>" alt="أيقونة">
                            <span>حاضنة أعمال جامعة الأغواط, QRGG+3QC, Laghouat</span>
                        </li>
                        <li class="position-relative">
                            <img src="<?php echo e(asset('assets/img/icons/mail-small.svg')); ?>" alt="أيقونة">
                            <span>البريد الإلكتروني :</span>
                            <a href="mailto:contact@soul-solo.com">contact@soul-solo.com</a>
                        </li>
                        <li class="position-relative">
                            <img src="<?php echo e(asset('assets/img/icons/phone-small.svg')); ?>" alt="أيقونة">
                            <span>الهاتف :</span> 
                            <a href="tel:96768678869">+213 6 68 375398</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 ps-xxl-4 pe-xxl-1" data-cue="slideInUp">
                <div class="footer-widget mb-30">
                    <h3 class="fs-20 fw-medium mb-12">اشترك في نشرتنا الإخبارية</h3>
                    <form action="#" class="newsletter-form position-relative">
                        <input type="email" class="fs-15 w-100 bg-transparent outline-0 text-color" placeholder="أدخل بريدك الإلكتروني">
                        <button class="position-absolute bg-transparent border-0 end-0">
                            <img src="<?php echo e(asset('assets/img/icons/plane-small.svg')); ?>" alt="أيقونة">
                        </button>
                    </form>
                    <div class="post-share d-flex flex-wrap align-items-center">
                        <span class="fw-medium me-2">تابعنا :</span>
                        <ul class="social-profile style-one list-unstyled mb-0">
                            <li><a href="https://www.facebook.com/" target="_blank" class="social-link"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="https://x.com/?lang=en" target="_blank" class="social-link"><i class="ri-twitter-x-line"></i></a></li>
                            <li><a href="https://www.instagram.com/" target="_blank" class="social-link"><i class="ri-instagram-line"></i></a></li>
                            <li><a href="https://www.linkedin.com/" target="_blank" class="social-link"><i class="ri-linkedin-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom position-relative overflow-hidden z-1" data-cue="fadIn">
        <div class="container-fluid position-relative px-xxl-4">
            <img src="<?php echo e(asset('assets/img/logo-large.png')); ?>" alt="شعار">
            <p class="copyright-text position-absolute round-oval d-inline-block text-center mb-0">
                <i class="ri-copyright-line"></i><span class="fw-semibold">Soul .Co</span>  كل الحقوق محفوظة لـ 
                <a href="#" target="_blank" class="link fw-semibold">Soul</a>
            </p>
        </div>
    </div>
</footer>

<!-- ================== CSS الوضع الداكن والفاتح للفوتر ================== -->
<style>
/* الوضع الداكن */
.theme-dark .footer-area {
    background-color: #0a0a0a !important;
    color: #f5f5f5;
}
.theme-dark .footer-area a,
.theme-dark .footer-area .text-color {
    color: #f5f5f5 !important;
}

/* الوضع الفاتح */
.theme-light .footer-area {
    background-color: #111 !important; /* أو #ffffff إذا تريد أبيض */
    color: #ffffff;
}
.theme-light .footer-area a,
.theme-light .footer-area .text-color {
    color: #ffffff;
}
</style>

<!-- ================== JS تغيير الوضع ================== -->
<script>
function setTheme(themeName) {
    localStorage.setItem('aixio_theme', themeName);
    document.documentElement.className = themeName;
}

function toggleTheme() {
    if (localStorage.getItem('aixio_theme') === 'theme-dark') {
        setTheme('theme-light');
    } else {
        setTheme('theme-dark');
    }
}

// تفعيل الوضع عند تحميل الصفحة
(function () {
    if (localStorage.getItem('aixio_theme') === 'theme-dark') {
        setTheme('theme-dark');
    } else {
        setTheme('theme-light');
    }
})();
</script>
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/footer.blade.php ENDPATH**/ ?>
<!-- ================== الفريق ================== -->
<div class="container style-one pt-130">
    <div class="row">
        <div class="col-xl-8 offset-xl-2 col-md-10 offset-md-1 text-center">
            <span class="section-subtitle style-two d-inline-block text_primary fw-bold fs-14 ls-15 mb-12">فريق العمل</span>
            <h2 class="section-title style-one fw-medium text-center text-title mb-40 px-xxl-5">سر نجاحنا</h2>
        </div>
    </div>
</div>

<div class="team-slider-wrap position-relative pb-130">
    <div class="container">
        <div class="team-slider-one swiper">
            <div class="swiper-wrapper">

                <?php
                    $team = [
                        [
                            'name' => 'أميرة بن صفدين',
                            'role' => 'عضو مؤسس لمشروع سول وأخصائية أرطوفونيا.',
                            'image' => 'assets/img/team/team-thumb-1.jpg',
                            'bg' => 'bg-1',
                        ],
                        [
                            'name' => 'إلياس مايدي',
                            'role' => 'عضو مؤسس و مدير أعمال الشركة و الجانب التسويقي',
                            'image' => 'assets/img/team/team-thumb-2.jpg',
                            'bg' => 'bg-2',
                        ],
                        [
                            'name' => 'مونى ملاح',
                            'role' => 'عضو مؤسس و مديرة تعليم الروبوتيك',
                            'image' => 'assets/img/team/team-thumb-3.jpg',
                            'bg' => 'bg-3',
                        ],
                        [
                            'name' => 'زياد خراف',
                            'role' => 'عضو مؤسس و مشرف الذكاء الاصطناعي',
                            'image' => 'assets/img/team/team-thumb-4.jpg',
                            'bg' => 'bg-4',
                        ],
                    ];
                ?>

                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="team-card style-one position-relative z-1 overflow-hidden text-center round-10">
                            <div class="team-member-bg <?php echo e($member['bg']); ?> position-absolute top-0 start-0 w-100 h-100 transition"></div>
                            <div class="team-thumb rounded-circle mx-auto">
                                <img src="<?php echo e(asset($member['image'])); ?>" alt="صورة" class="rounded-circle transition">
                            </div>
                            <div class="team-info position-relative z-1">
                                <h3 class="fs-20 fw-semibold text-title transition"><?php echo e($member['name']); ?></h3>
                                <span class="fs-15 d-block transition"><?php echo e($member['role']); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

    <div class="slider-btn">
        <button class="prev-btn team-prev bg-transparent border-0 d-flex flex-column align-items-center justify-content-center rounded-circle">
            <img src="<?php echo e(asset('assets/img/icons/left-arrow-large.svg')); ?>" alt="صورة">
        </button>
        <button class="next-btn team-next bg-transparent border-0 d-flex flex-column align-items-center justify-content-center rounded-circle">
            <img src="<?php echo e(asset('assets/img/icons/right-arrow-large.svg')); ?>" alt="صورة">
        </button>
    </div>
</div>
<!-- ================== نهاية الفريق ================== -->
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/Team.blade.php ENDPATH**/ ?>
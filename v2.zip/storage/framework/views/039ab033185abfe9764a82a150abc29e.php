<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="root">

    <title><?php echo $__env->yieldContent('title', 'Soul | FriendBand'); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/layerslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/default-animation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn-uicons.flaticon.com/uicons-regular-rounded/css/uicons-regular-rounded.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/soul.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/logo.css')); ?>">

    <!-- Font Awesome 6 CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        * { transition: all 0.3s ease-in-out; }
        .burger-nav { transition: left 0.4s ease-in-out; }
        #hamburger-button span { transition: all 0.4s ease; }
        html { scroll-behavior: smooth; }
        
        .hero-section {
          width: 100%;
          background-color: #020c1b;
          padding: 12rem 1rem !important;
          color: white;
        }
    </style>
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- JS Files -->
    <script src="<?php echo e(asset('assets/js/jquery-v3.4.1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/greensock.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/layerslider.transitions.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/layerslider.kreaturamedia.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.mb.YTPlayer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $(".player").YTPlayer({
                videoURL: "IebmQ6InnzQ",
                containment: "#video-container",
                autoPlay: true,
                mute: true,
                showControls: false, 
                loop: true,
                startAt: 0,
                stopAt: 0,
                quality: "large",
                optimizeDisplay: true,
                ratio: "16/9",
                playOnlyIfVisible: false,
                vol: 100,
                showYTLogo: false
            });
        });

        $('#hamburger-button').click(function(){
            $('#hamburger-button').toggleClass('open');
            $('.burger-nav').toggleClass('open');
        });
    </script>
</body>
</html>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>
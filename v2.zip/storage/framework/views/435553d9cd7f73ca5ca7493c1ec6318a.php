<section class="hero-section">
    <div class="hero-container" style="padding-top: 2rem;">
        <div class="hero-text">
            <h1>
                Smart Solutions for <span class="changing-word">Industry</span>
            </h1>
            <p>
                Soul develops innovative wearable technologies and AI-driven communication solutions 
                designed to enhance safety, productivity, and smart healthcare.
            </p>
            <a href="mailto:contact@soul-solo.com" class="hero-button">Discover Our Solutions</a>
        </div>
        <div class="hero-image">
            <img id="floating-clock" src="<?php echo e(asset('assets/images/watchSoul.png')); ?>" alt="Soul Co">
        </div>
    </div>
</section>

<style>
#floating-clock {
    display: block;
    margin: 0 auto;
    animation: float 2s ease-in-out infinite;
}

/* Animation: move up and down smoothly */
@keyframes float {
    0%   { transform: translateY(0); }
    50%  { transform: translateY(-20px); } /* goes up 20px */
    100% { transform: translateY(0); }     /* back to original */
}
</style>


<script>
const words = ["Autism", "Healthcare", "Industry", "YOU"];
const changingWord = document.querySelector(".changing-word");
let index = 0;

function changeWord() {
    // Fade out
    changingWord.style.opacity = 0;

    setTimeout(() => {
        // Change the text
        index = (index + 1) % words.length;
        changingWord.textContent = words[index];

        // Fade in
        changingWord.style.opacity = 1;
    }, 500); // duration of fade out
}

// Set initial opacity for smooth effect
changingWord.style.transition = "opacity 0.5s";

// Change word every 2 seconds
setInterval(changeWord, 2000);
</script>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/hero.blade.php ENDPATH**/ ?>
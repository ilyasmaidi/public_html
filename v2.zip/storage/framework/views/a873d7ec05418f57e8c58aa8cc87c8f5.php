<!-- ================== لماذا نحن ================== -->
<div class="wh-area style-three bg-f position-relative ptb-130">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-5 pe-xxl-0">
                <div class="wh-img-wrap round-10 mb-md-30">
                    <img src="<?php echo e(asset('assets/img/hero/GirlAutism.jpg')); ?>" alt="صورة" class="round-10 w-00">
                </div>
            </div>
            <div class="col-xl-6 col-lg-7 ps-xxl-4">
                <div class="wh-content">
                    <span class="d-block fs-14 fw-bold ls-15 text_primary mb-12">ما الذي يميزنا</span>
                    <h2 class="section-title style-one fw-medium text-title mb-10">
                        سول: رسالة نبيلة وإبداع لا حدود له وجودة لا تساوم
                    </h2>
                    <p class="mb-30">
                        نحن لا نصنع منتجات فقط، بل نصنع تغييرًا حقيقيًا يجعل الحياة أفضل.
                        فخرنا ليس بما أنجزناه فحسب، بل بما سنحققه غدًا من إنجازات أكبر.
                    </p>

                    <div class="row gx-xl-3 mb-35">
                        <?php
                            $features = [
                                'ثقافة الإبداع والابتكار',
                                'ثقافة التفكير التصميمي',
                                'ثقافة الفضول والتعلم المستمر',
                                'ثقافة السرعة والمرونة',
                                'ثقافة التمكين والثقة',
                                'ثقافة الاستدامة والتأثير الاجتماعي',
                            ];
                        ?>

                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="feature-item d-flex flex-wrap align-items-center bg-white round-10 mb-30">
                                    <i class="ri-arrow-right-circle-line"></i>
                                    <span class="fw-medium"><?php echo e($feature); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <a href="<?php echo e(route('login')); ?>" 
                       class="btn style-three fw-semibold position-relative round-oval">
                        اعرف المزيد عنا
                        <span class="position-absolute top-0 end-0 h-100 d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('assets/img/icons/right-arrow-white.svg')); ?>" alt="أيقونة">
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية لماذا نحن ================== -->
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/Choose.blade.php ENDPATH**/ ?>
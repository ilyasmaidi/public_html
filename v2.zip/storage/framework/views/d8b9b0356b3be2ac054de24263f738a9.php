
<?php $__env->startSection('title', 'Tele Autism - Soul'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   
    
    
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/teleautism.blade.php ENDPATH**/ ?>
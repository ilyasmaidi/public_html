<!-- ================== الميزات ================== -->
                <div class="container style-one">
  <div class="row">
    <!-- المميزات -->
    <div class="col-xxl-6 col-lg-7 mb-md-30">
      <div class="row">
        <!-- ذكاء اصطناعي لمتابعة الحالة -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-45">
            <h3 class="fs-20 fw-semibold text-title">ذكاء اصطناعي لمتابعة الحالة</h3>
            <p class="mb-0">يستخدم التطبيق خوارزميات ذكية لتحليل سلوك الطفل المصاب بالتوحد ومتابعة تطور حالته بشكل دقيق وفوري.</p>
          </div>
        </div>

        <!-- ربط مباشر بين الأطباء والأولياء -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-45">
            <h3 class="fs-20 fw-semibold text-title">ربط مباشر بين الأطباء والأولياء</h3>
            <p class="mb-0">يتيح التطبيق تواصلاً سهلاً بين الأطباء، الأولياء، والمختصين لتبادل الملاحظات والمتابعة اليومية لحالة الطفل.</p>
          </div>
        </div>

        <!-- نظام أرباح ذكي -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-30">
            <h3 class="fs-20 fw-semibold text-title">نظام أرباح ذكي</h3>
            <p class="mb-0">يوفر التطبيق آلية شفافة لتقاسم الأرباح بين المختصين والمؤسسات، مما يعزز الاستدامة والتعاون بين الأطراف.</p>
          </div>
        </div>

        <!-- إرشادات ودعم للأولياء -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-30">
            <h3 class="fs-20 fw-semibold text-title">إرشادات ودعم للأولياء</h3>
            <p class="mb-0">يحصل الأولياء على نصائح مخصصة وتمارين تفاعلية تساعدهم في التعامل مع أطفالهم ودعمهم بطريقة علمية.</p>
          </div>
        </div>

        <!-- مجتمع تفاعلي -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-30">
            <h3 class="fs-20 fw-semibold text-title">مجتمع تفاعلي</h3>
            <p class="mb-0">منصة تتيح للمستخدمين تبادل الخبرات بين العائلات والأطباء، وبناء شبكة دعم قوية في مجال التوحد.</p>
          </div>
        </div>

        <!-- لوحات تحكم وتقارير متقدمة -->
        <div class="col-md-6">
          <div class="feature-card style-three mb-30">
            <h3 class="fs-20 fw-semibold text-title">لوحات تحكم وتقارير متقدمة</h3>
            <p class="mb-0">تمكّن الأطباء والمؤسسات من الوصول إلى بيانات دقيقة وتقارير تفصيلية حول تقدم الحالات ونسب التحسن.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- صورة التطبيق -->
    <div class="col-xxl-5 offset-xxl-1 col-lg-5 ps-xxl-4 pe-xxl-0">
      <span class="section-subtitle style-three fs-14 fw-bold ls-15 d-inline-block text_primary mb-15">تطبيق Tele Autism</span>
      <img src="assets/img/app.png" alt="صورة تطبيق تيليا أوتيزم" class="feature-img d-block ms-auto rounded-3">
    </div>
  </div>
</div>
                <!-- ================== نهاية الميزات ================== --><?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/Feature.blade.php ENDPATH**/ ?>
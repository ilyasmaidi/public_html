<!-- Start Soul Team Section
====================================================-->
<section class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="title mb-30 w-50 lg-w-80 text-center mx-auto">
                    <span class="color-primary">Success with Soul</span>
                    <h2 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">Our Team</h2>
                    <p>
                        Our team is the heart of Soul. Passionate, creative, and committed, we combine innovation and expertise to deliver transformative solutions for healthcare, industry, and wearable technology.
                    </p>
                </div>
            </div>

            <div class="col-md-12 col-lg-12">
                <div class="owl-carousel team-slider-1 owl-nav-style-one position-relative mt-30">
                    
                    <!-- Founder -->
                    <div class="member-profile color-secondery-a">
                        <div class="overflow-hidden"><img src="<?php echo e(asset('public/amira.webp')); ?>" alt="image"></div>
                        <h4 class="mt-15"><a href="#">Amira B.</a></h4>
                        <span class="color-gray">Founder & CEO</span>
                        <p class="color-gray">Visionary leader driving Soul's mission to innovate in healthcare and wearable technology.</p>
                    </div>

                    <!-- Assistant Manager -->
                    <div class="member-profile color-secondery-a">
                        <div class="overflow-hidden">
                            <img src="<?php echo e(asset('public/zyad.webp')); ?>" alt="ZYAD KHERRAF">
                        </div>
                        <h4 class="mt-15"><a href="#">ZYAD KHERRAF</a></h4>
                        <span class="color-gray">Assistant Manager</span>
                        <p class="color-gray">
                            AI Student at ENSIA (2022–2027), passionate about machine learning and AI solutions.
                            Achievements include 2nd National Hackathon AgriChallenge, IMO participant, and multiple national debate awards.
                            Skilled in Python, C++, JavaScript, TensorFlow, PyTorch, React, PostgreSQL, and more.
                        </p>
                    </div>


                                            <!-- Project Manager -->
                        <div class="member-profile color-secondery-a">
                            <div class="overflow-hidden">
                                <img src="<?php echo e(asset('public/moh.webp')); ?>" alt="Mohammed Naoui Abbou">
                            </div>
                            <h4 class="mt-15"><a href="#">Mohammed Naoui Abbou</a></h4>
                            <span class="color-gray">Project Manager</span>
                            <p class="color-gray">
                                Software Engineer from Laghouat, Algeria, skilled in JavaScript, Java, Python, React, Flutter, and backend systems.
                                Experienced in UI/UX design, brand identity, workshops, and IT security. Passionate about delivering scalable and innovative solutions.
                            </p>
                        </div>


                    <!-- Lead Consultant -->
                    <div class="member-profile color-secondery-a">
                        <div class="overflow-hidden"><img src="<?php echo e(('public/mona.webp')); ?>" alt="image"></div>
                        <h4 class="mt-15"><a href="#">Mona Malah</a></h4>
                        <span class="color-gray">Lead Consultant</span>
                        <p class="color-gray">Provides strategic guidance to maximize impact across technology and healthcare solutions.</p>
                    </div>

                    <!-- Innovation Specialist -->
                    <div class="member-profile color-secondery-a">
                         
                        <div class="overflow-hidden"><img src="<?php echo e(('public/abir.webp')); ?>" alt="image"></div>
                        <h4 class="mt-15"><a href="#">Dr.Abir</a></h4>
                        <span class="color-gray">Student</span>
                        <p class="color-gray">Drives creative solutions and helps implement AI and wearable technology innovations.</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Soul Team Section
====================================================-->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/team.blade.php ENDPATH**/ ?>
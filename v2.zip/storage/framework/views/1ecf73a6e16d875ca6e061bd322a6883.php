<!-- ================== الدعوة للعمل ================== -->
<div class="cta-area style-three bg-f position-relative z-1 ptb-130 round-20">
    <style>
        /* ====== تغيير لون النص حسب الوضع ====== */
        .theme-light .text-auto-color {
            color: #000 !important; /* نص أسود في الوضع الفاتح */
            transition: color 0.3s ease;
        }

        .theme-dark .text-auto-color {
            color: #fff !important; /* نص أبيض في الوضع المظلم */
            transition: color 0.3s ease;
        }

        h2.section-title.style-one.text-auto-color.fw-medium.mb-0  {
    color: #fff !important;
    text-shadow: 3px -2px 11px rgb(0 0 0 / 55%);
}


    </style>

    <div class="container style-one">
        <div class="row align-items-center">
            <div class="col-xxl-5 col-md-6 pe-xxl-5 mb-md-30">
                <span class="section-subtitle style-three fs-14 fw-bold ls-15 d-inline-block text-auto-color mb-15" data-cue="slideInUp">
                    حمّل تطبيقنا الآن
                </span>
                <h2 class="section-title style-one text-auto-color fw-medium mb-0" data-cue="slideInUp" data-delay="300">
                    اكتشف تجربة جديدة تدمج الذكاء والسهولة في تطبيق واحد متكامل
                </h2>
            </div>

            <div class="col-xxl-6 offset-xxl-1 col-md-6">
                <div class="circle-text-wrap rounded-circle position-relative ms-md-auto">
                    <span class="bg_primary position-absolute d-flex flex-column align-items-center justify-content-center rounded-circle transition">
                        <img src="assets/img/icons/up-right-arrow-white.svg" alt="أيقونة" class="transition">
                    </span>
                    <img src="assets/img/request-demo.svg" alt="صورة نصية" class="circle-text d-block mx-auto rotate">
                    <a href="<?php echo e(route('contact')); ?>" class="position-absolute top-0 start-0 w-100 h-100 z-1"></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية الدعوة للعمل ================== -->
<?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/partials/Call.blade.php ENDPATH**/ ?>
<section class="about-us-3 position-relative bg-light">
    <div class="container">
        <div class="row">
            <!-- النصوص -->
            <div class="col-md-12 col-lg-12 col-xl-7">
                <div class="position-relative">
                    <div class="inner-title mb-30">
                        <h2 class="color-secondery slide-in-up">
                            Empowering Connections Through Technology
                        </h2>
                    </div>
                    <div class="text-area mb-30 slide-in-up">
                        <p class="mb-15">
                            Soul is a technology company specialized in software development and wearable solutions, with a focus on smart communication systems for both industrial and healthcare environments.
                        </p>
                        <p>
                            From enhancing safety and productivity in the oil & gas sector, to advancing telemedicine and AI-driven healthcare, our mission is to improve lives and create sustainable, intelligent solutions for the future.
                        </p>
                    </div>
                    <div class="about-area-box bg-secondery d-flex color-white p-40 slide-in-up">
                        <p class="pr-30">
                            Our multidisciplinary team of engineers, researchers, and designers work hand-in-hand to deliver user-friendly innovations. From real-time monitoring and wearable IoT devices to data-driven insights, we design solutions that empower industries, healthcare providers, and individuals alike.
                        </p>
                        <a class="float-right flat-small icon-primary" href="<?php echo e(url('about')); ?>">
                            <i class="flaticon-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- الصورة -->
            <div class="col-md-12 col-lg-12 col-xl-5">
                <div class="about-img xl-mt-50 slide-in-right">
                    <img src="<?php echo e(asset('assets/images/man.png')); ?>" alt="About Soul wearable technology" />
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/about.blade.php ENDPATH**/ ?>
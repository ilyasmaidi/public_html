@extends('layouts.app')
@section('title', 'Tele Autism - Soul')

@section('content')

    @include('partials.navbar')
   
    
    
    @include('partials.footer')

@endsection
<div {{ $attributes->merge(['class' => 'bg-secondery color-white', 'id' => 'scroll']) }} style="display: inline;">
    <i class="fa fa-angle-up"></i>
</div>

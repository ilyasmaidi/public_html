@extends('layouts.app')
@section('title', 'About Us - Soul')

@section('content')

    @include('partials.navbar')
    
   
    @include('partials.coom')
    
    @include('partials.footer')
    
    

@endsection


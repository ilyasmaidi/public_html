@extends('layouts.app')
@section('title', 'About Us - Soul')

@section('content')

    @include('partials.navbar')
   
    
    
    @include('partials.footer')

@endsection


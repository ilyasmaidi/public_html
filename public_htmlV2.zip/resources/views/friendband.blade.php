@extends('layouts.app')
@section('title', 'Friend Band - Soul')

@section('content')

    @include('partials.navbar')
   
    
    
    @include('partials.footer')

@endsection


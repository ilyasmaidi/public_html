@extends('layouts.app')
@section('title', 'Blog - Soul')

@section('content')

    @include('partials.navbar')
   
    
    
    @include('partials.footer')

@endsection


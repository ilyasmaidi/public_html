@extends('layouts.app')

@section('title', 'Soul - الصفحة الرئيسية')

@section('content')

    @include('partials.navbar')
    @include('partials.Hero')
    @include('partials.Funfact')
    @include('partials.Service')
    @include('partials.AboutUs')
    @include('partials.Works')
    @include('partials.Choose')
    @include('partials.Team')
    @include('partials.Testimonial')
    <br>
    
    @include('partials.Feature')
    @include('partials.Call')
    @include('partials.system')
    
    @include('partials.footer')

@endsection

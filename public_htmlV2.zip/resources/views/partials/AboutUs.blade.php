<!-- ================== من نحن ================== -->
                <div class="about-area style-three bg-black position-relative overflow-hidden z-1 ptb-130">
                    <img src="assets/img/about/about-shape-1.png" alt="شكل" class="section-shape-one position-absolute top-0 end-0 z-n1">
                    <img src="assets/img/about/about-shape-2.png" alt="شكل" class="section-shape-one position-absolute bottom-0 start-0 z-n1">
                    <div class="container style-one position-relative">
                        <img src="assets/img/about/womanT.jpg" alt="صورة" class="about-thumb round-10 move-left" style="max-width: 400px; z-index: -5000;">
                        <span class="d-block fs-14 fw-bold ls-15 text_secondary mb-12">من نحن</span>
                        <h2 class="section-title style-four fw-medium text-white pe-xxl-4">
                                نحن في شركة <span class="fw-semibold">سول</span>، شركة مختصة بتطوير
                                <span class="thumb round-oval"></span>
                                حلول وتقنيات موجهة لدعم مرضى التوحد
                                <span class="blur-text reveal-text"></span>
                            </h2>

                        <div class="circle-text-wrap position-relative z-1 rounded-circle d-flex flex-column align-items-center justify-content-center ms-auto">
                            <span class="exp-years font-secondary text-white fw-bold d-block">2</span>
                            <img src="assets/img/about/experience-text.png" alt="صورة" class="circle-text d-block mx-auto rotate">
                        </div>
                    </div>
                    <img src="assets/img/roboooo" alt="صورة" class="about-img position-absolute bottom-0 z-1 move-right">
                </div>
<!-- ================== نهاية من نحن ================== -->

<style>
    /* الوضع الفاتح */
.theme-light .text-auto-color {
  color: #000 !important;
}

/* الوضع المظلم */
.theme-dark .text-auto-color {
  color: #fff !important;
}

</style>

<!-- ================== قسم الخدمات ================== -->
<div class="container pt-130">
    <div class="row">
        <div class="col-xl-8 offset-xl-2 text-center">
            <span class="d-block fs-14 fw-bold ls-15 text_primary mb-12">خدماتنا</span>
            <h2 class="section-title style-one fw-medium text-center text-title mb-40">
                نحن نفخر بكل ما نقدمه، لأننا نؤمن بأن التأثير الحقيقي يأتي من الجمع بين الابتكار، الجودة، والقيم الإنسانية.
            </h2>
        </div>
    </div>
</div>

<div class="service-slider-wrap position-relative pb-130">
    <div class="container style-one">
        <div class="service-slider-one swiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="service-card style-three bg-1 d-flex flex-column align-items-center justify-content-between text-center position-relative z-1 round-5">
                        <img src="{{ asset('assets/img/services/service-card-shape-1.png') }}" alt="شكل" class="service-shape-one position-absolute top-0 end-0 trasnition">
                        <img src="{{ asset('assets/img/services/service-card-shape-2.png') }}" alt="شكل" class="service-shape-two position-absolute bottom-0 start-0 trasnition">
                        <h3 class="fs-20 fw-semibold"><a href="#" class="text-title link-hover-primary trasnition">تطبيق تيلي أوتيزم</a></h3>
                        <div class="service-icon">
                            <img src="{{ asset('assets/img/services/service-box-1.png') }}" alt="أيقونة" class="service-img d-block mx-auto">
                        </div>
                        <a href="{{ route('contact') }}" class="link style-two fw-semibold">قريباً<i class="ri-arrow-right-line"></i></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <div class="service-card style-three bg-2 d-flex flex-column align-items-center justify-content-between text-center position-relative z-1 round-5">
                        <img src="{{ asset('assets/img/services/service-card-shape-1.png') }}" alt="شكل" class="service-shape-one position-absolute top-0 end-0 trasnition">
                        <img src="{{ asset('assets/img/services/service-card-shape-2.png') }}" alt="شكل" class="service-shape-two position-absolute bottom-0 start-0 trasnition">
                        <h3 class="fs-20 fw-semibold"><a href="#" class="text-title link-hover-primary trasnition">سوار ذكي يتفاعل مع التطبيق</a></h3>
                        <div class="service-icon">
                            <img src="{{ asset('assets/img/services/service-box-2.png') }}" alt="أيقونة" class="service-img d-block mx-auto">
                        </div>
                        <a href="{{ route('contact') }}" class="link style-two fw-semibold">قريباً<i class="ri-arrow-right-line"></i></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <div class="service-card style-three bg-3 d-flex flex-column align-items-center justify-content-between text-center position-relative z-1 round-5">
                        <img src="{{ asset('assets/img/services/service-card-shape-1.png') }}" alt="شكل" class="service-shape-one position-absolute top-0 end-0 trasnition">
                        <img src="{{ asset('assets/img/services/service-card-shape-2.png') }}" alt="شكل" class="service-shape-two position-absolute bottom-0 start-0 trasnition">
                        <h3 class="fs-20 fw-semibold"><a href="#" class="text-title link-hover-primary trasnition">أنظمة المستودعات واللوجستيات الذكية</a></h3>
                        <div class="service-icon">
                            <img src="{{ asset('assets/img/services/service-box-3.png') }}" alt="أيقونة" class="service-img d-block mx-auto">
                        </div>
                       <a href="{{ route('contact') }}" class="link style-two fw-semibold">قريباً<i class="ri-arrow-right-line"></i></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <div class="service-card style-three bg-4 d-flex flex-column align-items-center justify-content-between text-center position-relative z-1 round-5">
                        <img src="{{ asset('assets/img/services/service-card-shape-1.png') }}" alt="شكل" class="service-shape-one position-absolute top-0 end-0 trasnition">
                        <img src="{{ asset('assets/img/services/service-card-shape-2.png') }}" alt="شكل" class="service-shape-two position-absolute bottom-0 start-0 trasnition">
                        <h3 class="fs-20 fw-semibold"><a href="#" class="text-title link-hover-primary trasnition">أنظمة فحص الجودة</a></h3>
                        <div class="service-icon">
                            <img src="{{ asset('assets/img/services/service-box-4.png') }}" alt="أيقونة" class="service-img d-block mx-auto">
                        </div>
                        <a href="{{ route('contact') }}" class="link style-two fw-semibold">قريباً<i class="ri-arrow-right-line"></i></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <div class="service-card style-three bg-4 d-flex flex-column align-items-center justify-content-between text-center position-relative z-1 round-5">
                        <img src="{{ asset('assets/img/services/service-card-shape-1.png') }}" alt="شكل" class="service-shape-one position-absolute top-0 end-0 trasnition">
                        <img src="{{ asset('assets/img/services/service-card-shape-2.png') }}" alt="شكل" class="service-shape-two position-absolute bottom-0 start-0 trasnition">
                        <h3 class="fs-20 fw-semibold"><a href="#" class="text-title link-hover-primary trasnition">الصيانة التنبؤية بالذكاء الاصطناعي</a></h3>
                        <div class="service-icon">
                            <img src="{{ asset('assets/img/services/service-box-1.png') }}" alt="أيقونة" class="service-img d-block mx-auto">
                        </div>
                        <a href="{{ route('contact') }}" class="link style-two fw-semibold">قريباً<i class="ri-arrow-right-line"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="slider-btn">
        <button class="prev-btn service-prev bg-transparent border-0 d-flex flex-column align-items-center justify-content-center rounded-circle">
            <img src="{{ asset('assets/img/icons/left-arrow-large.svg') }}" alt="صورة">
        </button>
        <button class="next-btn service-next bg-transparent border-0 d-flex flex-column align-items-center justify-content-center rounded-circle">
            <img src="{{ asset('assets/img/icons/right-arrow-large.svg') }}" alt="صورة">
        </button>
    </div>
</div>
<!-- ================== نهاية قسم الخدمات ================== -->

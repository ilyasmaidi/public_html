<!-- ================== قسم الإحصائيات ================== -->
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 px-lg-0">
            <div class="counter-card-wrap style-one d-flex flex-wrap">

                <!-- فيديو توعوي عن التوحد -->
                <div class="counter-card style-three">
                    <div class="counter-video bg-f position-relative">
                        <a data-fslightbox="video1" href="https://youtu.be/TTZDsI809pw" class="play-video d-flex flex-wrap align-items-center justify-content-center">
                            <span class="play-icon d-flex flex-column align-items-center justify-content-center rounded-circle bg_secondary">
                                <i class="ri-play-large-fill"></i>
                            </span>
                            <span class="play-text fs-xxl-18 fw-semibold text-white ls-1">شاهد المزيد من سوول</span>
                        </a>
                    </div>
                </div>

                <!-- عدد مرضى التوحد حول العالم -->
                <div class="counter-card style-three d-flex flex-column align-items-start justify-content-center">
                    <h4 class="font-secondary fw-semibold text-black"><span class="transition">75</span>م+</h4>
                    <p class="fs-14 fw-semibold ls-1 d-block mb-0">عدد الأشخاص المصابين بالتوحد حول العالم</p>
                </div>

                <!-- المشاريع الصحية الذكية -->
                <div class="counter-card style-three d-flex flex-column align-items-start justify-content-center">
                    <h4 class="font-secondary fw-semibold text-black"><span class="transition">120</span>+</h4>
                    <p class="fs-14 fw-semibold ls-1 d-block mb-0">مشروع في مجال الرعاية الصحية الذكية</p>
                </div>

                <!-- الأجهزة القابلة للارتداء المطورة -->
                <div class="counter-card style-three d-flex flex-column align-items-start justify-content-center">
                    <h4 class="font-secondary fw-semibold text-black"><span class="transition">30</span>+</h4>
                    <p class="fs-14 fw-semibold ls-1 d-block mb-0">جهاز قابل للارتداء لدعم التواصل لذوي الاحتياجات الخاصة</p>
                </div>

                <!-- معدل النجاح في تحسين التواصل -->
                <div class="counter-card style-three d-flex flex-column align-items-start justify-content-center">
                    <h4 class="font-secondary fw-semibold text-black"><span class="transition">95</span>%</h4>
                    <p class="fs-14 fw-semibold ls-1 d-block mb-0">معدل نجاح حلولنا في تحسين التواصل</p>
                </div>

                <!-- فريق الخبراء والمتخصصين -->
                <div class="counter-card style-three d-flex flex-column align-items-start justify-content-center">
                    <h4 class="font-secondary fw-semibold text-black"><span class="transition">60</span>+</h4>
                    <p class="fs-14 fw-semibold ls-1 d-block mb-0">خبراء في الذكاء الاصطناعي والطب عن بُعد</p>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية قسم الإحصائيات ================== -->

<section class="why-choose-us bg-white">
    <div class="container">
        <div class="row">
            <!-- الصورة والفيديو -->
            <div class="col-md-12 col-lg-5 col-xl-5">
                <div class="why-us-img-2 z-index-1 mb-30 position-relative lg-mt-50 wow animated slideInLeft">
                    <img src="<?php echo e(asset('assets/images/video.png')); ?>" alt="Soul Co">
                    
                    <div class="personal-video xy-middle">
                        <a data-fancybox class="video-popup bg-primary color-white" href="https://youtu.be/MTW7H5UQ8Ts">
                            <i class="fa fa-play"></i>
                        </a>
                        <div class="loader">
                            <div class="loader-inner ball-scale-multiple">
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- النصوص -->
            <div class="col-md-12 col-lg-7 col-xl-7">
                <div class="why-us mb-30 wow animated slideInRight">
                    <h2 class="mb-30 color-secondery wow animated slideInUp">
                        Soul Co – Smart Solutions for Healthcare & Industry
                    </h2>
                    <p class="mb-15 wow animated slideInUp">
                        At Soul Co, we empower industries, healthcare providers, and individuals with innovative technology solutions. Our expertise includes wearable devices, AI-powered analytics, telemedicine, and smart communication tools.
                    </p>
                    <p class="wow animated slideInUp">
                        We integrate technology, strategy, and user-centered design to deliver solutions that enhance safety, productivity, and quality of life for individuals and organizations alike.
                    </p>
                </div>
            </div>

            <!-- Fact Counter -->
            <div class="col-xl-12">
                <div class="fact-counter">
                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-xl-3">
                            <div class="achivement-style-2 flat-small bg-gray px-30 py-40 color-secondery count wow animated slideInUp text-center" data-wow-delay="300ms" data-wow-duration="500ms">
                                <span class="position-relative icon-white"><i class="fa-solid fa-users"></i></span>
                                <div class="achive-count-three mt-20 count-num color-primary font-highlight" data-speed="3000" data-stop="30000000">30M</div>
                                <h5 class="achive-three-title pt-5">People Benefiting from Our Solutions</h5>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3">
                            <div class="achivement-style-2 flat-small bg-gray px-30 py-40 mt-50 color-secondery count wow animated slideInUp md-mb-20 text-center" data-wow-delay="300ms" data-wow-duration="500ms">
                                <span class="position-relative icon-white"><i class="fa-solid fa-hands-helping"></i></span>
                                <div class="achive-count-three mt-20 count-num color-primary font-highlight" data-speed="3000" data-stop="15000">15K</div>
                                <h5 class="achive-three-title pt-5">Professionals Supported</h5>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3">
                            <div class="achivement-style-2 flat-small bg-gray px-30 py-40 color-secondery count wow animated slideInUp text-center" data-wow-delay="300ms" data-wow-duration="500ms">
                                <span class="position-relative icon-white"><i class="fa-solid fa-award"></i></span>
                                <div class="achive-count-three mt-20 count-num color-primary font-highlight" data-speed="3000" data-stop="120">120</div>
                                <h5 class="achive-three-title pt-5">Recognitions Achieved</h5>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3">
                            <div class="achivement-style-2 flat-small bg-gray px-30 py-40 mt-50 bf-transparent color-secondery count wow animated slideInUp text-center" data-wow-delay="300ms" data-wow-duration="500ms">
                                <span class="position-relative icon-white"><i class="fa-solid fa-lightbulb"></i></span>
                                <div class="achive-count-three mt-20 count-num color-primary font-highlight" data-speed="3000" data-stop="500">500</div>
                                <h5 class="achive-three-title pt-5">Innovative Solutions</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/why-choose-us.blade.php ENDPATH**/ ?>
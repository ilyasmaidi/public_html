<!-- Font Awesome 4.7 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Start Footer One
====================================================-->
<footer class="bg-secondery">
  <div class="container">
    <div class="row py-80">
      
      <!-- Footer Column 1 -->
      <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="footer-widget sm-mt-0">
          <div class="footer-logo mb-20">
            <!-- <a href="#"><img src="<?php echo e(asset('assets/images/logo/logo-white.png')); ?>" alt="Logo"></a> -->
          </div>
          <div class="text-area color-white">
            <p>Discover a deeper connection with yourself through mindful practices, meditation tips, and soulful guidance for daily life.</p>
          </div>
          <ul class="widget-contact-info color-white icon-primary link-list-b-15 mt-30">
            <li><span class="mr-20"><i class="fa fa-phone" aria-hidden="true"></i></span> +213656771568</li>
            <li><span class="mr-20"><i class="fa fa-envelope" aria-hidden="true"></i></span> info@soul-solo.com</li>
            <li><span class="mr-20"><i class="fa fa-skype" aria-hidden="true"></i></span> Sky.soul-solo.com</li>
            <li><span class="mr-20"><i class="fa fa-map-marker" aria-hidden="true"></i></span>Laghouat Alg</li>
          </ul>
        </div>
      </div>

      <!-- Footer Column 2 (Soul Connect) -->
      <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="footer-widget">
          <h3 class="footer-widget-title position-relative va-lb-line-w50-h2-primary pb-15 mb-20 color-white">Soul Connect</h3>
          <ul class="hover-white-primary link-list-b-20"> 
            <li>
              <a href="#">Connect with your inner self</a>
              <div class="post-meta color-light-gray f-12 mt-5">
                <span class="d-inline-block">01 August 2025</span>
              </div>
            </li>
            <li>
              <a href="#">Meditation tips for daily life</a>
              <div class="post-meta color-light-gray f-12 mt-5">
                <span class="d-inline-block">05 August 2025</span>
              </div>
            </li>
            <li>
              <a href="#">Soulful practices for beginners</a>
              <div class="post-meta color-light-gray f-12 mt-5">
                <span class="d-inline-block">10 August 2025</span>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <!-- Footer Column 3 -->
      <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="footer-widget">
          <h3 class="footer-widget-title position-relative va-lb-line-w50-h2-primary pb-15 mb-20 color-white">Links</h3>
          <ul class="hover-white-primary link-list-b-15">
            <li><a href="https://soul-solo.com/about">About Us</a></li>
            <!--<li><a href="#">How It Work</a></li>-->
            <!--<li><a href="#">FAQ</a></li>-->
            <!--<li><a href="#">Help</a></li>-->
            <!--<li><a href="#">Free Consultation</a></li>-->
            <!--<li><a href="#">Mission and Vision</a></li>-->
            <!--<li><a href="#">Account Settings</a></li>-->
            <!--<li><a href="#">License</a></li>-->
          </ul>
        </div>
      </div>

      <!-- Footer Column 4 -->
      <div class="col-xl-4 col-lg-8 col-md-6">
        <div class="footer-widget color-white xl-mt-50">
          <h3 class="footer-widget-title position-relative va-lb-line-w50-h2-primary pb-15 mb-20 color-white">Subscribe</h3>
          <p>Dictum velit cum arcu interd faucib urna inceptos imperdiet dignissim.</p>
          <form class="mt-30" id="subscribeForm">
            <input class="form-control" name="subscribe" type="email" placeholder="Subscribe" required>
            <button type="submit" class="btn btn-primary mt-15">Subscribe</button>
            <p id="subscribeMessage" class="mt-10 text-success" style="display:none;">Done!</p>
        </form>
          <!-- <ul class="social media-two d-inline-block color-secondery mt-30">
            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
          </ul> -->
        </div>
      </div>

    </div>
  </div>

  <hr class="border-t-1-dark">

  <div class="copyright-2 bg-secondery">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <ul class="copyright-style-2 d-table w-100 hover-primary color-white py-15">
            <li class="float-left">Soul @ 2025. All Right Reserved.</li>
            <!--<li class="float-right color-white-a"><a href="#">Privacy Policy</a> | <a href="#"> Terms & Conditions</a></li>-->
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- End Footer One-->



<script>
    // التعامل مع الفورم
    document.getElementById('subscribeForm').addEventListener('submit', function(e) {
        e.preventDefault(); // منع ارسال الفورم
        const message = document.getElementById('subscribeMessage');
        message.style.display = 'block'; // عرض الرسالة
        // يمكن إخفاؤها بعد 3 ثواني
        setTimeout(() => {
            message.style.display = 'none';
        }, 3000);
        // إعادة تعيين الفورم
        e.target.reset();
    });
</script><?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/footer.blade.php ENDPATH**/ ?>
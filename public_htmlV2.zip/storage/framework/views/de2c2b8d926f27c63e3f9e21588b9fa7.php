
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Smart wearable solutions for autistic children">
	<meta name="keywords" content="autism, wearable, child safety, emotion monitoring, technology">
	<meta name="author" content="root">

	<!-- CSS Links -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" >
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/word-sheet.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/color.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/default-animation.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/fonts/flaticon/flaticon.css')); ?>">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
  	
	<title>Smart Autism Care - Coming Soon</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

	<style>
		/* Top Icon Buttons */
		.top-buttons {
			position: fixed;
			top: 15px;
			width: 100%;
			padding: 0 20px;
			z-index: 9999;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		/* Icon Buttons Style */
		.icon-btn {
			display: inline-flex;
			justify-content: center;
			align-items: center;
			color: #fff;
			background: rgba(255,255,255,0.1);
			border-radius: 50%;
			padding: 8px 12px;
			font-size: 1.2rem;
			transition: all 0.4s ease;
			box-shadow: 0 2px 8px rgba(0,0,0,0.2);
		}

		.icon-btn i {
			pointer-events: none;
		}

		.icon-btn:hover {
			transform: scale(1.3) rotate(10deg);
			box-shadow: 0 6px 20px rgba(255,255,255,0.5);
			background: rgba(255,255,255,0.2);
			color: #fffa;
		}

		/* Responsive for mobile */
		@media (max-width: 576px) {
			.icon-btn {
				padding: 6px 10px;
				font-size: 1rem;
			}
		}
	</style>
</head>
<body id="top">



<div class="coming-soon vh-100 position-relative overlay-secondery-8 min-max-h-auto" style="background: url('https://cdn.fusionchat.ai/blog/chatgpt/blackrock-and-microsoft-plan-us-30b-fund-to-invest-in-ai-energy-----u15if5r1xpuu3aq7c9luo.png') center center/ cover;">
	<div class="container h-100">
		<div class="row h-100">
			<div class="col-md-12 col-lg-12 h-100 min-max-h-auto">
				<div class="banner-content y-middle z-index-1 position-relative text-center d-table m-auto color-white">
					
					<a href="#"><img style="width: 200px; height: auto; margin-bottom: 15px;" src="<?php echo e(asset('assets/images/S.png')); ?>" alt="logo"></a>
					
					<div class="text-area w-60 d-table m-auto sm-w-100">
						<p>We’re building smart wearable technology to support autistic children—helping families, caregivers, and educators with real-time emotional insights.</p>
					</div>
					
				<h1 class="banner-title cd-headline clip is-full-width my-15 text-uppercase d-table mx-auto">
    <span class="cd-words-wrapper color-white">
        <b class="is-visible">جاري تحديث الموقع</b>
        <b>نعمل على تحسين تجربتك</b>
        <b>قريبًا سنكون جاهزين</b>
    </span>
</h1>

					<hr class="border-t-1-white w-75 d-table mx-auto">
					
					<div class="countup my-30 text-center d-table mx-auto md-my-15" id="countup1">
					  <span class="timeel days">00</span>
					  <span class="count-text timeRefDays">days</span>
					  <span class="timeel hours">00</span>
					  <span class="count-text timeRefHours">hours</span>
					  <span class="timeel minutes">00</span>
					  <span class="count-text timeRefMinutes">minutes</span>
					  <span class="timeel seconds">00</span>
					  <span class="count-text timeRefSeconds">seconds</span>
					</div>
					<hr class="border-t-1-white w-75 d-table m-auto">
					
					
				</div>
			</div>
		</div>
	</div>
</div>

<!-- JS Scripts -->
<script src="<?php echo e(asset('assets/js/jquery-v3.4.1.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

<script>
window.onload = function() {
    var countDownDate = new Date("August 24, 2025 12:00:00").getTime();

    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;

        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementsByClassName('days')[0].innerHTML = days;
        document.getElementsByClassName('hours')[0].innerHTML = hours;
        document.getElementsByClassName('minutes')[0].innerHTML = minutes;
        document.getElementsByClassName('seconds')[0].innerHTML = seconds;

        if (distance < 0) {
            clearInterval(x);
            document.getElementById("countup1").innerHTML = "EXPIRED";
        }
    }, 1000);
};
</script>

</body>
</html>
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/comingsoon.blade.php ENDPATH**/ ?>
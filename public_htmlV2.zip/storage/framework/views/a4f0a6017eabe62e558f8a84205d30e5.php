<!-- Start Partners One -->
<div class="our-partners-two bg-gray position-relative py-80">
    <div class="container">
        <div class="row align-items-center">
            <!-- Title Section -->
            <div class="col-md-12 col-lg-5">
                <div class="title mb-30 wow animated slideInLeft">
                    <span class="color-primary">Our Valuable Partners</span>
                    <h2 class="position-relative va-lb-line-w50-h2-primary pb-15 mb-20">Fellows We Have</h2>
                    <p>
                        We collaborate with top organizations to bring the best solutions for autism care and technology innovation.
                    </p>
                </div>
            </div>

            <!-- Partners Carousel -->
            <!-- <div class="col-md-12 col-lg-7">
                <div class="owl-carousel slide-4 owl-dots-none flat-big icon-secondery text-center">
                    <img src="<?php echo e(asset('assets/images/partners/envato.png')); ?>" alt="Envato" class="mx-4">
                    <img src="<?php echo e(asset('assets/images/partners/themeforest.png')); ?>" alt="ThemeForest" class="mx-4">
                    <img src="<?php echo e(asset('assets/images/partners/codecanyon.png')); ?>" alt="CodeCanyon" class="mx-4">
                    <img src="<?php echo e(asset('assets/images/partners/graphicriver.png')); ?>" alt="GraphicRiver" class="mx-4">
                    <img src="<?php echo e(asset('assets/images/partners/audiojungle.png')); ?>" alt="AudioJungle" class="mx-4">
                </div>
            </div> -->
        </div>
    </div>
</div>
<!-- End Partners One -->

<style>
    .our-partners-two:before {
    position: absolute;
    content: "";
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    opacity: .07;
    background: url(https://avatars.mds.yandex.net/i?id=7f2b7c69711b0c03c61afb3b424a7ca9c290e3cb-10702829-images-thumbs&n=13) no-repeat center center / cover !important;
}
</style><?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/partners.blade.php ENDPATH**/ ?>
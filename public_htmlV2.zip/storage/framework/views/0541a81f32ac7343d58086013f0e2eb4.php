<!-- Hero Section Start -->
                <div class="hero-area style-three bg-f">
                    <div class="container-fluid position-relative z-1">
                        <div class="row align-items-xxl-start align-items-center">
                            <div class="col-lg-6">
                                <div class="hero-content">
                                    <h6 class="section-subtitle d-inline-block fs-13 fw-semibold ls-1 bg_secondary text-black round-oval" data-cue="slideInUp" data-delay="100">رسالتنا هي تسخير التكنولوجيا للارتقاء بحياتكم</h6>
                                    <h1 class="font-secondary fw-normal text-black" data-cue="slideInUp" data-delay="400">نحن شركة متخصصة في تطوير البرمجيات <span class="fw-bold">والتكنولوجيا القابلة للارتداء</span></h1>
                                    <div class="btn-wrap" data-cue="slideInUp" data-delay="600">
                                        <a href="login.html" class="btn style-three fw-semibold position-relative round-oval">اكتشف حلولنا<span class="position-absolute top-0 end-0 h-100 d-flex flex-column align-items-center justify-content-center"><img src="assets/img/icons/right-arrow-white.svg" alt="Icon"></span></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="hero-img-wrap position-relative z-1">
                                    <img src="assets/img/hero/family.jpg" alt="Image" class="d-block me-auto moveContent">
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <!-- Hero Section End --><?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/partials/Hero.blade.php ENDPATH**/ ?>
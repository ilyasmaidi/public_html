<!-- Start Header ==================================================== -->
<!-- القائمة الجانبية -->
<div class="burger-nav bg-secondery" id="navbarSupportedContent">
    

    <ul class="navbar-nav color-white-a px-20 py-10">
        <!-- روابط أساسية -->
        <li class="nav-item">
            <a href="https://soul-solo.com/" class="nav-link">Home</a>
        </li>
        <li class="nav-item">
            <a href="https://soul-solo.com/about" class="nav-link">About Us</a>
        </li>
        <li class="nav-item">
            <a href="https://soul-solo.com/friendband" class="nav-link">Friend Band</a>
        </li>
        <li class="nav-item">
            <a href="https://soul-solo.com/teleautism" class="nav-link">Tele Autism</a>
        </li>
        <li class="nav-item">
            <a href="mailto:support@soul-solo.com" class="nav-link">Contact Us</a>
        </li>

        <!-- قسم التواصل -->
        <li class="nav-item mt-4">
            <div class="nav-contact color-white-a">
                <h4 class="mb-2 color-white">We're Available 24/7</h4>
                <ul class="icon-primary">
                    <li><i class="fa fa-phone mr-2"></i> +213656771568</li>
                    <li><i class="fa fa-envelope mr-2"></i> support@soul-solo.com</li>
                </ul>
                <h4 class="mt-3 mb-2 color-white">Find Us</h4>
                <ul class="socal media-two d-flex gap-2">
                    <li><a href="https://facebook.com" aria-label="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com" aria-label="Twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://linkedin.com" aria-label="LinkedIn"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://instagram.com" aria-label="Instagram"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="https://dribbble.com" aria-label="Dribbble"><i class="fa fa-dribbble"></i></a></li>
                </ul>
            </div>
        </li>
    </ul>
</div>





<header id="header" class="header-3 nav-on-top">
    <div class="top-header bg-secondery color-white icon-primary d-md-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-9">
                    <ul>
                        <li><i class="fa fa-phone mr-10"></i>+213656771568</li>
                        <li><i class="fa fa-envelope mr-10"></i>support@soul-solo.com</li>
                    </ul>
                </div>
                <div class="col-lg-5 col-md-3">
                    <ul class="color-white-a hover-primary float-right">
                        <li class="nav-item">
                            <!--<form class="search-field p-0">-->
                            <!--    <input type="search" class="search form-control" placeholder="Search Here"/>-->
                            <!--    <span>-->
                            <!--        <i class="fa fa-search"></i>-->
                            <!--        <i class="fa fa-times"></i>-->
                            <!--    </span>-->
                            <!--</form>-->
                        </li>
                        <!--<li><a href="<?php echo e(route('login')); ?>">Login</a></li>-->
                        <!--<li><a href="<?php echo e(route('register')); ?>">Signup</a></li>-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="nav-header bg-white py-10">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light px-0">
                        <a class="navbar-brand" style="width: 80px;" href="https://soul-solo.com"><img src="<?php echo e(asset('assets/images/S.png')); ?>" alt="logo" ></a>
                            <div class="slide-nav-area ml-auto">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <div id="hamburger-button">
                                            <span></span>
                                            <span></span>
                                            <span></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End Header ==================================================== -->


<style>
@media (max-width: 768px) { /* يطبق فقط على الموبايل والتابلت */
    div#navbarSupportedContent {
        width: 80% !important;
    }
}
</style>
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/header.blade.php ENDPATH**/ ?>
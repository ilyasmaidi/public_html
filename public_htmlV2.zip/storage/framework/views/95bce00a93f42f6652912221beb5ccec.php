<div>
    
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.Breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="text-center my-5">
        <button wire:click="increment" class="btn btn-primary">+</button>
        <h1><?php echo e($count); ?></h1>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/livewire/contact-form.blade.php ENDPATH**/ ?>
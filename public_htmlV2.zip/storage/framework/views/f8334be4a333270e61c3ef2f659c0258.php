<!-- ================== الثقافة والقيم ================== -->
<div class="container style-one pt-130 pb-100">
    <div class="row">
        <div class="col-xxl-6 offset-xxl-3 col-xl-8 offset-xl-2 col-md-10 offset-md-1 text-center">
            <span class="d-block fs-14 fw-bold ls-15 text_primary mb-12">ثقافتنا</span>
            <h2 class="section-title style-one fw-medium text-center text-title mb-30">
                نحن أكثر من فريق عمل، نحن عائلة واحدة، والابتكار يبدأ من هنا
            </h2>
        </div>
    </div>

    <div class="row justify-content-center process-card-wrap">
        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
            <div class="process-card style-two mb-30">
                <div class="process-counter-wrap d-flex flex-wrap align-items-center justify-content-between">
                    <span class="process-counter-name">S</span>
                    <span class="process-counter bg_primary d-flex flex-column align-items-center justify-content-center rounded-circle">01</span>
                </div>
                <h3 class="fs-20 fw-semibold mb-15">القوة</h3>
                <p class="pe-xxl-5 mb-0">
                    نستمد قوتنا من إصرار الأطفال المصابين بالتوحد على التواصل والتطور يوماً بعد يوم رغم التحديات.
                </p>
            </div>
        </div>

        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 ps-xxl-4">
            <div class="process-card style-two mb-30">
                <div class="process-counter-wrap d-flex flex-wrap align-items-center justify-content-between">
                    <span class="process-counter-name">O</span>
                    <span class="process-counter bg_primary d-flex flex-column align-items-center justify-content-center rounded-circle">02</span>
                </div>
                <h3 class="fs-20 fw-semibold">التفاؤل</h3>
                <p class="pe-xxl-4 mb-0">
                    نؤمن أن كل خطوة صغيرة نحو الوعي والعلاج تفتح باباً جديداً للأمل في مستقبل أفضل للأطفال.
                </p>
            </div>
        </div>

        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 ps-xxl-4">
            <div class="process-card style-two mb-30">
                <div class="process-counter-wrap d-flex flex-wrap align-items-center justify-content-between">
                    <span class="process-counter-name">U</span>
                    <span class="process-counter bg_primary d-flex flex-column align-items-center justify-content-center rounded-circle">03</span>
                </div>
                <h3 class="fs-20 fw-semibold">العالمية</h3>
                <p class="pe-xxl-4 mb-0">
                    نطمح إلى عالمٍ أكثر شمولاً يفهم التوحد ويتعامل معه بحب وتقدير لكل اختلاف.
                </p>
            </div>
        </div>

        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 ps-xxl-4">
            <div class="process-card style-two mb-30">
                <div class="process-counter-wrap d-flex flex-wrap align-items-center justify-content-between">
                    <span class="process-counter-name">L</span>
                    <span class="process-counter bg_primary d-flex flex-column align-items-center justify-content-center rounded-circle">04</span>
                </div>
                <h3 class="fs-20 fw-semibold">المحبة</h3>
                <p class="pe-xxl-4 mb-0">
                    نؤمن أن الحب هو اللغة التي تجمعنا وتمنح أطفال التوحد شعور الأمان والانتماء.
                </p>
            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية الثقافة والقيم ================== -->
<?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/partials/Works.blade.php ENDPATH**/ ?>
<!-- Gallery Start
====================================================-->
<section class="projects">
    <div class="video-banner">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xl-12">
                    <div class="title mb-30 w-50 text-center mx-auto wow animated slideInUp">
                        <span class="color-primary">Our Innovative Solutions in Action</span>
                        <h2 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">Soul Co Previous Work</h2>
                        <p>We create technology-driven solutions for autism support. Our projects demonstrate our commitment to enhancing communication, safety, and independence for children and families.</p>
                    </div>
                </div>
                <div class="col-xl-12 p-0">
                    <div id="video-container" class="mt-30 wow animated slideInUp" style="width: 100%; height: 900px;">
                        <div id="play-video" class="player" 
                            data-property="{videoURL: 'IebmQ6InnzQ', containment: '#video-container', showControls: false, autoPlay: true, loop: true, vol: 100, mute: true, startAt: 0, stopAt: 0, opacity: 1, addRaster: false, quality: 'large', optimizeDisplay: true, ratio: 16/9}">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="gallery-video" style="margin-top: -200px">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="project-item">
                        <div class="project-img bg-secondery p-10 wow animated slideInLeft">
                            <img src="<?php echo e(asset('assets/images/GirlAutism.jpg')); ?>" alt="Girl using Soul Co device">
                        </div>
                        <div class="project-content mt-20">
                            <h4 class="mb-5">Empowering Children</h4>
                            <span class="color-light-gray">Autism Support, Technology, Innovation</span>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6">
                    <div class="project-item mt-30">
                        <div class="project-img bg-secondery p-10 wow animated slideInRight">
                            <img src="<?php echo e(asset('assets/images/family.jpg')); ?>" alt="Family using Soul Co solutions">
                        </div>
                        <div class="project-content mt-20">
                            <h4 class="mb-5">Supporting Families</h4>
                            <span class="color-light-gray">Safety, Communication, Peace of Mind</span>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6">
                    <div class="project-item mt-30">
                        <div class="project-img bg-secondery p-10 wow animated slideInLeft">
                            <img src="<?php echo e(asset('assets/images/womanB.jpg')); ?>" alt="Therapist with Soul Co device">
                        </div>
                        <div class="project-content mt-20">
                            <h4 class="mb-5">Professional Use</h4>
                            <span class="color-light-gray">Therapist Tools, Real-time Monitoring</span>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-6">
                    <div class="project-item mt-30">
                        <div class="project-img bg-secondery p-10 wow animated slideInRight">
                            <img src="<?php echo e(asset('assets/images/womanT.jpg')); ?>" alt="Specialist using Soul Co technology">
                        </div>
                        <div class="project-content mt-20">
                            <h4 class="mb-5">Specialist Insights</h4>
                            <span class="color-light-gray">Data-driven, Emotional Analysis, Support</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Gallery End
====================================================-->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/gallery.blade.php ENDPATH**/ ?>
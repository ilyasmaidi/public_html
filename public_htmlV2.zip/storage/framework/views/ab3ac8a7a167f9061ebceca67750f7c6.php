<!-- Testimonial Start - Soul Content
====================================================-->
<section class="bg-light">
    <div class="container">
        <div class="row">
            <!-- Section Title -->
            <div class="col-md-12 col-lg-5 col-xl-5">
                <div class="title">
                    <span class="color-primary">Testimonials</span>
                    <h2 class="position-relative va-lb-line-w50-h2-primary pb-15 mb-30">
                        What Our Clients Say About Soul
                    </h2>
                    <p>
                        At Soul, we strive for excellence in healthcare, industry, and wearable technology. Here's what our esteemed clients have to say about their experience working with us.
                    </p>
                </div>
                <div class="admin-info w-100 d-inline-block mt-20">
                    <div class="admin-bio float-left">
                        <h4 class="color-secondery">Dr. Emily Roberts</h4>
                        <span class="color-gray d-inline-block">CEO, HealthTech Innovations</span>
                    </div>
                    <div class="feedback-2 icon-primary float-right">
                        <i class="flaticon-star-1"></i>
                        <i class="flaticon-star-1"></i>
                        <i class="flaticon-star-1"></i>
                        <i class="flaticon-star-1"></i>
                        <i class="flaticon-star-1"></i>
                    </div>
                </div>
            </div>

            <!-- Testimonials Carousel -->
            <div class="col-md-12 col-lg-7 col-xl-7">
                <div class="owl-carousel testimonial-1 lg-mt-30">
                    <!-- Testimonial 1 -->
                    <div class="testimonial-four position-relative bg-white">
                        <div class="position-relative text-center py-40 px-30">
                            <h4 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">James Anderson</h4>
                            <div class="text-area">
                                <p>
                                    Working with Soul was transformative. Their AI solutions for industrial processes increased our efficiency by 40% and greatly improved workflow automation.
                                </p>
                            </div>
                            <div class="feedback-2 icon-primary mt-20">
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 2 -->
                    <div class="testimonial-four position-relative bg-white">
                        <div class="position-relative text-center py-40 px-30">
                            <h4 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">Sophia Williams</h4>
                            <div class="text-area">
                                <p>
                                    Soul’s wearable technology solutions have been a game-changer for our healthcare projects. Exceptional service and attention to detail!
                                </p>
                            </div>
                            <div class="feedback-2 icon-primary mt-20">
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 3 -->
                    <div class="testimonial-four position-relative bg-white">
                        <div class="position-relative text-center py-40 px-30">
                            <h4 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20">Dr. Michael Tan</h4>
                            <div class="text-area">
                                <p>
                                    The Soul team is highly innovative and reliable. Their AI-driven solutions helped optimize our production line, saving time and reducing errors significantly.
                                </p>
                            </div>
                            <div class="feedback-2 icon-primary mt-20">
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                                <i class="flaticon-star-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial End - Soul Content
====================================================-->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/test.blade.php ENDPATH**/ ?>
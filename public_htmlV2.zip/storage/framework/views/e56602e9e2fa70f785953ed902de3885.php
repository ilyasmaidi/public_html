<!-- ================== الهيدر ================== -->
<div class="navbar-area style-two position-relative" id="navbar">
    <div class="container-fluid">
        <div class="navbar-wrapper d-flex justify-content-between align-items-center">

            <!-- شعار الموقع -->
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
                <img src="<?php echo e(asset('assets/img/solo.png')); ?>" alt="شعار" class="logo-light" style="max-width: 40px; max-height: 40px;">
                <img src="<?php echo e(asset('assets/img/solo-white.png')); ?>" alt="شعار" class="logo-dark" style="max-width: 40px;">
            </a>

            <!-- القائمة -->
            <div class="menu-area mx-auto">
                <div class="overlay"></div>
                <nav class="menu">
                    <div class="menu-mobile-header">
                        <button type="button" class="menu-mobile-arrow bg-transparent border-0">
                            <i class="ri-arrow-left-s-line"></i>
                        </button>
                        <div class="menu-mobile-title"></div>
                        <button type="button" class="menu-mobile-close bg-transparent border-0">
                            <i class="ri-close-line"></i>
                        </button>
                    </div>

                    <ul class="menu-section p-0 mb-0 lh-1">
                        <li>
                            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">الرئيسية</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('coom')); ?>" class="<?php echo e(request()->routeIs('friendband') ? 'active' : ''); ?>">Friend Band</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('coom')); ?>" class="<?php echo e(request()->routeIs('teleautism') ? 'active' : ''); ?>">Tele Autism</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('coom')); ?>" class="<?php echo e(request()->routeIs('aboutsoul') ? 'active' : ''); ?>">من نحن</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('coom')); ?>" class="<?php echo e(request()->routeIs('blog') ? 'active' : ''); ?>">المدونة</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- الأزرار الجانبية -->
            <div class="other-options d-flex flex-wrap align-items-center justify-content-end">
                <div class="option-item">
                    <div class="d-flex flex-wrap align-items-center">
                        <div class="mobile-options position-relative d-lg-none me-3">
                            <button class="dropdown-toggle text-center bg-transparent border-0 p-0 transition" type="button" data-bs-toggle="dropdown" aria-expanded="true">
                                <i class="ri-more-fill"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-centered mobile-option-list top-1 border-0" data-bs-popper="static">
                                <a href="<?php echo e(route('contact')); ?>" class="btn style-three fw-semibold position-relative round-oval">
                                    تواصل معنا
                                    <span class="position-absolute top-0 end-0 h-100 d-flex flex-column align-items-center justify-content-center">
                                        <img src="<?php echo e(asset('assets/img/icons/right-arrow-white.svg')); ?>" alt="أيقونة">
                                    </span>
                                </a>
                            </div>
                        </div>

                        <button class="search-btn bg-transparent border-0 d-flex flex-wrap align-items-center dropdown-toggle text-center p-0 transition" type="button" data-bs-toggle="dropdown" aria-expanded="true">
                            <img src="<?php echo e(asset('assets/img/icons/search.svg')); ?>" alt="أيقونة البحث">
                        </button>
                        <div class="search-dropdown dropdown-menu dropdown-menu-right top-1 border-0" data-bs-popper="static">
                            <form class="search-popup position-relative" action="#">
                                <input type="search" class="form-control text-para" placeholder="ابحث هنا....">
                                <button type="submit" class="position-absolute top-0 end-0 h-100 border-0 bg-transparent d-flex flex-column align-items-center justify-content-center">
                                    <i class="ri-search-2-line"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="option-item d-lg-block d-none">
                    <a href="<?php echo e(route('contact')); ?>" class="btn style-three fw-semibold position-relative round-oval">
                        تواصل معنا
                        <span class="position-absolute top-0 end-0 h-100 d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('assets/img/icons/right-arrow-white.svg')); ?>" alt="أيقونة">
                        </span>
                    </a>
                </div>

                <div class="option-item d-lg-none">
                    <button type="button" class="menu-mobile-trigger">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ================== نهاية الهيدر ================== -->
<?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/partials/navbar.blade.php ENDPATH**/ ?>
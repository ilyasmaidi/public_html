<!-- Breadcrumb Start -->
                <div class="breadcrumb-area bg-f round-20 position-relative z-1">
                    <div class="container text-center">
                        <ul class="br-menu text-center bg_secondary d-inline-block list-unstyled mb-15">
                            <li class="position-relative fs-13 fw-semibold ls-1 d-inline-block"><a href="index.html">HOME</a></li>
                            <li class="position-relative fs-13 fw-semibold ls-1 d-inline-block">CONTACT US</li>
                        </ul>
                        <h2 class="section-title style-one fw-medium font-secondary text-black text-center mb-6">Contact Us</h2>
                    </div>
                </div>
                <!-- Breadcrumb End --><?php /**PATH C:\Users\mr code\Downloads\Downloads\newsoulv1\public_html\resources\views/partials/Breadcrumb.blade.php ENDPATH**/ ?>
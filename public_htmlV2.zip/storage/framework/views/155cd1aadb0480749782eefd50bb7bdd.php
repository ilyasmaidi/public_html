<!-- Brand Section Start -->
                <div class="container style-two pt-130">
                    <div class="brand-slider-one swiper">
                        <div class="swiper-wrapper align-items-center">
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-1.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-2.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-3.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-4.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-5.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-6.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-7.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-8.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                           <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-1.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-3.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="brand-logo style-one">
                                    <img src="assets/img/brand/brand-4.svg" alt="Logo" class="d-block mx-auto">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Brand Section End --><?php /**PATH C:\Users\PC-Orange\Downloads\newsoulv1\public_html\resources\views/partials/Brand.blade.php ENDPATH**/ ?>
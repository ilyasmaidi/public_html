<!-- Start About Us
====================================================-->
<?php
    $sectionTitle = "About Soul";
    $discoverText = "Discover";
    $aboutParagraph1 = "Soul is a specialized company in developing software and wearable technologies, focusing on augmented and alternative communication solutions in industrial environments and the healthcare sector. We provide innovative solutions for oil & gas industries to enhance safety and productivity, and we develop advanced telemedicine and AI-based technologies to enable smart healthcare and improve the quality of life, especially for people with special needs.";

    $aboutParagraph2 = "Our technologies rely on Artificial Intelligence and the Internet of Things, enabling us to develop advanced data analytics solutions, smart communication systems, and wearable devices that revolutionize the way industries and healthcare providers work and connect. Our vision is to empower organizations and individuals to make the most of modern technology and use it to enhance lives.";

    $identityTitle = "Soul Identity";
    $identityItems = [
        "S: Strength",
        "O: Optimism",
        "U: Univers",
        "L: Love",
    ];
    $identityQuote = "Love gives us the strength to live in a universe filled with optimism.";

    $missionTitle = "Our Mission";
    $missionText = "Our mission is to harness technology to improve lives, with a special focus on supporting people with special needs and enhancing their quality of life.";

    $sloganTitle = "Our Slogan";
    $sloganText = "Soul plays solo. Always finding solutions, and when technology moves one step forward, Soul moves two.";
?>

<section class="about-us">
	<div class="container">
		<div class="row">
			<!-- Text Section -->
			<div class="col-md-12 col-lg-8 col-xl-7">
				<div class="why-us">
					<div class="title">
						<span class="color-primary"><?php echo e($discoverText); ?></span>
						<h2 class="position-relative va-lb-line-w50-h2-primary pb-15 mb-30">
							<?php echo e($sectionTitle); ?>

						</h2>
					</div>

					<p class="mb-15"><?php echo e($aboutParagraph1); ?></p>
					<p><?php echo e($aboutParagraph2); ?></p>

					<hr class="my-30">

					<!-- Identity -->
					<div class="mb-30">
						<h4 class="color-primary mb-10"><?php echo e($identityTitle); ?></h4>
						<ul>
							<?php $__currentLoopData = $identityItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><strong><?php echo e(explode(':', $item)[0]); ?></strong>: <?php echo e(explode(':', $item)[1]); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						<p class="mt-10">"<?php echo e($identityQuote); ?>"</p>
					</div>

					<!-- Mission -->
					<div class="mb-30">
						<h4 class="color-primary mb-10"><?php echo e($missionTitle); ?></h4>
						<p><?php echo e($missionText); ?></p>
					</div>

					<!-- Slogan -->
					<div class="mb-30">
						<h4 class="color-primary mb-10"><?php echo e($sloganTitle); ?></h4>
						<p><?php echo e($sloganText); ?></p>
					</div>
				</div>
			</div>

			<!-- Image + Video -->
			<div class="col-md-12 col-lg-4 col-xl-5">
				<div class="why-us-img z-index-1 position-relative mb-20 ml-20 lg-mt-50">
					<img src="https://www.cio.com/wp-content/uploads/2023/05/autistic-adults-finding-tech-jobs-100632201-orig.jpg?quality=50&amp;strip=all&amp;w=1024" alt="About Soul">
					<div class="personal-video xy-middle">
						<a data-fancybox class="video-popup bg-primary color-white" 
						   href="https://youtu.be/TJuwhCIQQTs">
							<i class="fa fa-play" aria-hidden="true"></i>
						</a>
						<div class="loader">
							<div class="loader-inner ball-scale-multiple">
								<div></div><div></div><div></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End About Image + Video -->
		</div>
	</div>
</section>
<!-- End About Us -->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/AboutUs.blade.php ENDPATH**/ ?>
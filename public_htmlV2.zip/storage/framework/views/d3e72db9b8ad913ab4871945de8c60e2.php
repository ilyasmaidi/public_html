<?php
    // History Section Variables
    $historyTitle = "History";
    $historyHeading = "Soul Company Journey";
    $historyIntro = "Soul is a small startup specializing in wearable technology and software solutions, focusing on helping small businesses and the healthcare sector with practical and innovative ideas.";

    $historyTimeline = [
        [
            "year" => "2022",
            "title" => "Soul Founded",
            "desc" => "Soul was founded as a startup focused on wearable technology and software solutions, with an emphasis on small business and healthcare applications.",
            "img"  => "https://avatars.mds.yandex.net/i?id=34e927efd5bc7e0dc6a289dbaf1d9dc68e6e384f-12920410-images-thumbs&n=13"
        ],
        [
            "year" => "2023",
            "title" => "First Small Projects",
            "desc" => "The company completed its first small projects, including simple and practical solutions for healthcare and industrial clients, learning key lessons in operations and client management.",
            "img"  => "https://ntf-iro.ru/wp-content/uploads/2019/04/04171522967067.jpg"
        ],
        [
            "year" => "2024",
            "title" => "Service Expansion",
            "desc" => "Soul expanded its services, providing a wider range of software and tech solutions to small businesses and healthcare clients, maintaining quality and reliability.",
            "img"  => "https://avatars.mds.yandex.net/i?id=a4db5bd236ecde230d958b2dd399774f265d4888-6961846-images-thumbs&n=13"
        ]
    ];
?>

<!-- Our History Start
====================================================-->
<section class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="title mb-30 w-50 lg-w-80 text-center mx-auto">
                    <span class="color-primary"><?php echo e($historyTitle); ?></span>
                    <h2 class="position-relative va-c-line-w50-h1-primary pb-15 mb-20"><?php echo e($historyHeading); ?></h2>
                    <p><?php echo e($historyIntro); ?></p>
                </div>
            </div>
            <div class="col">
                <div class="owl-carousel history-timeline mt-30 owl-nav-style-one">

                    <?php $__currentLoopData = $historyTimeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="history-item bg-white">
                            <div class="row">
                                <div class="col-lg-5">
                                    <div style="background: url(<?php echo e($event['img']); ?>); width: 100%; height: 100%"></div>
                                </div>
                                <div class="col-lg-7">
                                    <div class="text-area py-40 pr-30 lg-pl-30">
                                        <span class="color-primary"><?php echo e($event['year']); ?></span>
                                        <h4 class="mb-20"><?php echo e($event['title']); ?></h4>
                                        <p><?php echo e($event['desc']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- Our History End
====================================================-->
<?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/History.blade.php ENDPATH**/ ?>
<!-- Why Choose Soul Start 
====================================================-->
<section class="choose-us-one bg-secondery">
    <div class="container">
        <div class="position-relative z-index-1">
            <div class="row justify-content-start">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="title color-white mb-30">
                        <span class="color-primary">Why Choose Soul</span>
                        <h2 class="position-relative va-lb-line-w50-h2-primary pb-15 mb-30 w-75 color-white w-80-mobile">
                            We Empower Lives Through Innovative Technology & Compassion
                        </h2>
                        <p class="w-80-mobile">
                            At Soul, we don’t just create technology—we craft solutions that improve quality of life, especially for people with special needs. Our wearable tech, AI, and IoT innovations help industries and healthcare work smarter, safer, and more efficiently.
                        </p>
                    </div>
                </div>
                <div class="col-md-12 col-lg-12 col-xl-8 offset-lg-0">
                    <div class="row">
                        <div class="col-md-6 col-lg-6">
                            <div class="box-style-7 color-white flat-medium mt-30 icon-primary">
                                <h4 class="box-title mb-20 color-white">Innovative Solutions</h4>
                                <p class="w-80-mobile">
                                    We create smart, AI-driven solutions and wearable devices that transform communication and work in industrial and healthcare sectors.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6">
                            <div class="box-style-7 color-white flat-medium mt-30 icon-primary">
                                <h4 class="box-title mb-20 color-white">Human-Centered Impact</h4>
                                <p class="w-80-mobile">
                                    Our products enhance the lives of individuals, especially those with special needs, combining technology with care and empathy.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6">
                            <div class="box-style-7 color-white flat-medium mt-30 icon-primary">
                                <h4 class="box-title mb-20 color-white">Agility & Flexibility</h4>
                                <p class="w-80-mobile">
                                    We adapt quickly to challenges, emergencies, and technological advancements, ensuring continuous innovation and rapid solutions.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6">
                            <div class="box-style-7 color-white flat-medium mt-30 icon-primary">
                                <h4 class="box-title mb-20 color-white">Trusted Team & Support</h4>
                                <p class="w-80-mobile">
                                    Our passionate team works like a family, empowering each other, clients, and partners while providing reliable support around the clock.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Why Choose Soul End -->

<style>
    .choose-us-one:after {
    content: "";
    position: absolute;
    top: 0;
    left: auto;
    right: 0;
    background: url(https://avatars.mds.yandex.net/get-altay/12814440/2a000001915b091c368cbef41e36c7d7bd2e/orig) no-repeat 65% 0% / cover;
    width: 35%;
    height: 100%;
}

@media (max-width: 576px) {
  .w-80-mobile {
    width: 60% !important;
  }
}

</style><?php /**PATH /home/uskfgmyu/public_html/resources/views/partials/ChooseUsStart.blade.php ENDPATH**/ ?>